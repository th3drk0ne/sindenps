#include "Descriptors.h"

// --------- Device descriptor (Namco GunCon2 identity) ---------
// NOTE: For PS2 recognition we mimic real GunCon2:
//  VID:PID = 0x0B9A:0x016A, USB 1.1, 8-byte EP0, class at interface.
const USB_Descriptor_Device_t PROGMEM DeviceDescriptor =
{
    .Header                 = {.Size = sizeof(USB_Descriptor_Device_t), .Type = DTYPE_Device},
    .USBSpecification       = VERSION_BCD(01.00),
    .Class                  = USB_CSCP_NoDeviceClass,
    .SubClass               = USB_CSCP_NoDeviceSubclass,
    .Protocol               = USB_CSCP_NoDeviceProtocol,
    .Endpoint0Size          = FIXED_CONTROL_ENDPOINT_SIZE, // 8

    .VendorID               = CPU_TO_LE16(0x0B9A),
    .ProductID              = CPU_TO_LE16(0x016A),
    .ReleaseNumber          = CPU_TO_LE16(0x0100),

    .ManufacturerStrIndex   = NO_DESCRIPTOR,
    .ProductStrIndex        = NO_DESCRIPTOR,
    .SerialNumStrIndex      = NO_DESCRIPTOR,

    .NumberOfConfigurations = FIXED_NUM_CONFIGURATIONS
};

// --------- Configuration descriptor ---------
// 1 interface, vendor class 0xFF, subclass 0x6A, 1x Interrupt IN EP (8 bytes, 8ms)
const USB_Descriptor_Configuration_t PROGMEM ConfigurationDescriptor =
{
    .Config = {
        .Header                 = {.Size = sizeof(USB_Descriptor_Configuration_Header_t), .Type = DTYPE_Configuration},
        .TotalConfigurationSize = sizeof(USB_Descriptor_Configuration_t),
        .TotalInterfaces        = 1,
        .ConfigurationNumber    = 1,
        .ConfigurationStrIndex  = NO_DESCRIPTOR,
        .ConfigAttributes       = USB_CONFIG_ATTR_RESERVED,
        .MaxPowerConsumption    = USB_CONFIG_POWER_MA(50),
    },

    .GCN2_Interface = {
        .Header                 = {.Size = sizeof(USB_Descriptor_Interface_t), .Type = DTYPE_Interface},
        .InterfaceNumber        = INTERFACE_ID_GCN2,
        .AlternateSetting       = 0,
        .TotalEndpoints         = 1,
        .Class                  = 0xFF,   // vendor-specific
        .SubClass               = 0x6A,   // GunCon2
        .Protocol               = 0x00,
        .InterfaceStrIndex      = NO_DESCRIPTOR,
    },

    .GCN2_ReportINEndpoint = {
        .Header                 = {.Size = sizeof(USB_Descriptor_Endpoint_t), .Type = DTYPE_Endpoint},
        .EndpointAddress        = GCN2_EPADDR_IN,
        .Attributes             = (EP_TYPE_INTERRUPT | ENDPOINT_ATTR_NO_SYNC | ENDPOINT_USAGE_DATA),
        .EndpointSize           = GCN2_EPSIZE,
        .PollingIntervalMS      = 8,
    },
};

uint16_t CALLBACK_USB_GetDescriptor(const uint16_t wValue, const uint16_t wIndex,
                                    const void** const DescriptorAddress)
{
    const uint8_t DescriptorType   = (wValue >> 8);
    const void* Address = NULL;
    uint16_t    Size    = NO_DESCRIPTOR;

    switch (DescriptorType)
    {
        case DTYPE_Device:
            Address = &DeviceDescriptor;
            Size    = sizeof(DeviceDescriptor);
            break;

        case DTYPE_Configuration:
            Address = &ConfigurationDescriptor;
            Size    = sizeof(ConfigurationDescriptor);
            break;

        // No String or HID descriptors (not HID device)
    }

    *DescriptorAddress = Address;
    return Size;
}
