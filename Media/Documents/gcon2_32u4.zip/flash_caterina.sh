#!/usr/bin/env bash
set -euo pipefail
# Linux/macOS helper for Caterina bootloader flash
# Usage: ./flash_caterina.sh /dev/ttyACM0
PORT=${1:-/dev/ttyACM0}
make CATERINA_PORT=$PORT caterina
