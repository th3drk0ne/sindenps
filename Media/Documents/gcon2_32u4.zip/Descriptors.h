#pragma once
#include <LUFA/Drivers/USB/USB.h>

// ========= USB endpoint config =========
#define GCN2_EPADDR_IN   (ENDPOINT_DIR_IN  | 1)
#define GCN2_EPSIZE      8

typedef struct
{
    USB_Descriptor_Configuration_Header_t Config;

    // Vendor-specific interface (0xFF/0x6A), 1x IN interrupt EP
    USB_Descriptor_Interface_t GCN2_Interface;
    USB_Descriptor_Endpoint_t  GCN2_ReportINEndpoint;
} USB_Descriptor_Configuration_t;

// Interface ID
enum
{
    INTERFACE_ID_GCN2 = 0,
};

// String IDs (unused, PS2 doesn't need them)
enum
{
    STRING_ID_Language = 0,
    STRING_ID_Manufacturer,
    STRING_ID_Product,
};

uint16_t CALLBACK_USB_GetDescriptor(const uint16_t wValue,
                                    const uint16_t wIndex,
                                    const void** const DescriptorAddress);
