# GunCon2 (Namco) Replica for ATmega32U4 (Pro Micro/Leonardo)

This firmware enumerates as a **GunCon 2** on a **PS2**, consumes the **SerialPortSecondary** 6-byte frame from your Sinden OG-console pipeline over **Serial1 @ 115200**, and maps a momentary **pedal on D10** to **Button A** (active-low on USB report) – ideal for **Time Crisis**.

## Features
- Vendor-specific USB device (class 0xFF / subclass 0x6A), VID:PID **0x0B9A:0x016A** for authentic PS2 recognition.
- One Interrupt IN endpoint (EP1 IN, 8 bytes, 8 ms interval).
- 6-byte **SerialPortSecondary** frame parser per video frame:
  - `Byte0=222`, `Byte1=X(0..256)`, `Byte2=Y(0..256)`,
  - `Byte3` bits: Trigger, PumpAction, FrontLeft, FrontRight, BackLeft, BackRight (ACTIVE-HIGH)
  - `Byte4` bits: DPad Up/Down/Left/Right (ACTIVE-HIGH)
  - `Byte5=223`.
- Buttons are **ACTIVE-LOW** in the USB report (like a real GunCon2).
- Coordinate scaling: 0..256 → ~**640×240** (X→1..639, Y→1..239). Adjust in `scaleX/scaleY` if desired.
- Calibration/control OUT packets (class 0x21, bRequest 0x09, length 6) are accepted and stored.

## Wiring
- **D10 (PB6)** ↔ **pedal** (other side to **GND**). Internal pull-up enabled.
- **Pi TX** → **Pro Micro RX1** (pin 0) at **115200 8N1**.
- Common **GND** between Pi and Pro Micro.
- Micro-USB from Pro Micro to **PS2 USB** port.

## Build
1. Install `avr-gcc`, `avr-libc`, `avrdude`.
2. **Download LUFA** and set `LUFA_PATH` in `Makefile` to its root (where the `LUFA/` folder lives).
3. Build:
   ```bash
   make clean && make
   ```
4. Flash (double-tap reset on Pro Micro to enter Caterina bootloader):
   ```bash
   make caterina
   ```

## Button Mapping
- GunCon2 bits (ACTIVE-LOW): Trigger=13, Start=15, Select=14, A=3, B=2, C=1, DPad Up/Right/Down/Left=4/5/6/7.
- Serial `Byte3` → GunCon2:
  - bit0 Trigger → 13
  - bit1 PumpAction → C (1)
  - bit2 FrontLeft → A (3)
  - bit3 FrontRight → B (2)
  - bit4 BackLeft → Select (14)
  - bit5 BackRight → Start (15)
- Serial `Byte4` (DPad): Up/Down/Left/Right → 4/6/7/5 respectively (note: Right is bit 5).
- **Pedal D10** → **Button A** (held while pressed). Change to B/C/Select/Start by editing the two lines under the comment `Pedal → Button A` in `GunCon2.c`.

## Notes
- Off-screen shots use (0,0); this firmware **never** emits (0,0) unless you add that logic.
- If aim is offset on your setup, tweak `scaleX/scaleY` multipliers.
- If a title expects the gun on USB **Port 2**, plug accordingly.

## License
This repository is provided as-is for hobbyist use.
