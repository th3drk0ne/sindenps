/*
 * GunCon2 replica for ATmega32U4 (Pro Micro/Leonardo) using LUFA.
 *
 * - Enumerates as Namco GunCon2 (vendor class, subclass 0x6A)
 * - Interrupt IN EP: 8 bytes @ 8ms
 * - Consumes "SerialPortSecondary" frames on Serial1 @115200:
 *     [0]=222, [1]=X(0..256), [2]=Y(0..256),
 *     [3]=btn bits (Trigger/Pump/FrontL/FrontR/BackL/BackR),
 *     [4]=dpad bits (Up/Down/Left/Right),
 *     [5]=223
 * - Pedal on D10 (PB6) → Button A
 * - Buttons are ACTIVE-LOW on USB report (like real GunCon2).
 */

#define F_CPU 16000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/power.h>
#include <util/delay.h>
#include <string.h>
#include "Descriptors.h"
#include <LUFA/Drivers/USB/USB.h>

// ========= UART (USART1) for SerialPortSecondary =========
static void UART_Init(void)
{
    // 115200 8N1 @16MHz → UBRR1 ~ 8
    UBRR1 = 8;
    UCSR1A = 0;
    UCSR1B = _BV(RXEN1) | _BV(TXEN1);
    UCSR1C = _BV(UCSZ11) | _BV(UCSZ10); // 8N1
}
static inline uint8_t UART_Available(void) { return (UCSR1A & _BV(RXC1)); }
static inline uint8_t UART_Read(void)      { while(!UART_Available()); return UDR1; }

// ========= Pedal on D10 (PB6) =========
#define PEDAL_DDR   DDRB
#define PEDAL_PORT  PORTB
#define PEDAL_PINR  PINB
#define PEDAL_BIT   PB6     // Arduino D10 pin on 32U4
static inline void PEDAL_Init(void)
{
    PEDAL_DDR  &= ~_BV(PEDAL_BIT); // input
    PEDAL_PORT |=  _BV(PEDAL_BIT); // pull-up
}
static inline uint8_t PEDAL_IsPressedRaw(void)
{
    // Momentary to GND -> pressed when reads 0
    return (PEDAL_PINR & _BV(PEDAL_BIT)) == 0;
}
static uint8_t pedalPressed = 0, pedalStable = 0, pedalCnt = 0;
#define PEDAL_DB_COUNT  3

// ========= GunCon2 report =========
// 6 bytes total on the wire (buttons[0..1], x[2..3], y[4..5])
typedef union {
    uint8_t raw[6];
    struct {
        uint16_t buttons;   // ACTIVE-LOW
        int16_t  x;
        int16_t  y;
    } __attribute__((packed));
} GCN2_Report_t;

static volatile GCN2_Report_t g_report = { .raw = {0xFF,0xFF, 1,0, 1,0} };

// Host "Set Param" (class OUT) fields for calibration/progressive
static volatile uint16_t paramX = 0, paramY = 0, paramMode = 0;
#define GCN2_FLAG_PROGRESSIVE 0x0100

// ========= USB events & control =========
void EVENT_USB_Device_Connect(void)   {}
void EVENT_USB_Device_Disconnect(void){}

void EVENT_USB_Device_ConfigurationChanged(void)
{
    Endpoint_ConfigureEndpoint(GCN2_EPADDR_IN, EP_TYPE_INTERRUPT, GCN2_EPSIZE, 1);
}

void EVENT_USB_Device_ControlRequest(void)
{
    // Mirror "Class Interface OUT, bRequest=0x09, wLength=6"
    if ((USB_ControlRequest.bmRequestType == (REQDIR_HOSTTODEVICE | REQTYPE_CLASS | REQREC_INTERFACE)) &&
         USB_ControlRequest.bRequest      == 0x09 &&
         USB_ControlRequest.wLength       == 6)
    {
        Endpoint_ClearSETUP();
        uint8_t buf[6];
        Endpoint_Read_Control_Stream_LE(buf, sizeof(buf));
        Endpoint_ClearOUT();

        paramX    = (uint16_t)buf[0] | ((uint16_t)buf[1] << 8);
        paramY    = (uint16_t)buf[2] | ((uint16_t)buf[3] << 8);
        paramMode = (uint16_t)buf[4] | ((uint16_t)buf[5] << 8);
    }
}

// ========= Send current report when host polls =========
static inline void GCN2_TrySend(void)
{
    Endpoint_SelectEndpoint(GCN2_EPADDR_IN);
    if (Endpoint_IsINReady())
    {
        GCN2_Report_t out = g_report;
        if (paramMode & GCN2_FLAG_PROGRESSIVE)
            out.buttons |= GCN2_FLAG_PROGRESSIVE;
        Endpoint_Write_Stream_LE(&out, sizeof(out), NULL);
        Endpoint_ClearIN();
    }
}

// ========= SerialPortSecondary 6-byte frame parser =========
#define SP2_HDR  222
#define SP2_FTR  223

// Scale 0..256 → 1..639 (X), 1..239 (Y); keep 0 reserved for off-screen
static inline int16_t scaleX(uint8_t v)
{
    if (v > 256) v = 256;
    uint16_t out = (uint16_t)(((uint32_t)v * 638) / 256) + 1; // 1..639
    if (out == 0) out = 1;
    return (int16_t)out;
}
static inline int16_t scaleY(uint8_t v)
{
    if (v > 256) v = 256;
    uint16_t out = (uint16_t)(((uint32_t)v * 238) / 256) + 1; // 1..239
    if (out == 0) out = 1;
    return (int16_t)out;
}

static inline void press_if(uint8_t cond, uint16_t bit, uint16_t* buttons)
{
    if (cond) *buttons &= ~(1u << bit);  // press (active-low)
    else      *buttons |=  (1u << bit);  // release
}

// Read one frame if available; update g_report.{x,y,buttons}
static void UpdateFromSerialPortSecondary(void)
{
    if (!UART_Available()) return;
    uint8_t b0 = UART_Read();
    if (b0 != SP2_HDR) return;

    uint8_t buf[5];
    for (uint8_t i=0;i<5;i++) buf[i] = UART_Read();
    if (buf[4] != SP2_FTR) return; // bad footer

    const uint8_t sx  = buf[0];
    const uint8_t sy  = buf[1];
    const uint8_t b1  = buf[2];  // Trigger/Pump/FrontL/FrontR/BackL/BackR
    const uint8_t bd  = buf[3];  // DPad U/D/L/R

    // Coordinates
    g_report.x = scaleX(sx);
    g_report.y = scaleY(sy);

    // Start with "all released"
    uint16_t btn = 0xFFFF;

    // Byte4 mapping (incoming ACTIVE-HIGH)
    // GunCon2 bits (ACTIVE-LOW): Trigger=13, Start=15, Select=14,
    // A=3, B=2, C=1, Dpad U/R/D/L=4/5/6/7
    press_if((b1 & _BV(0)), 13, &btn); // Trigger
    press_if((b1 & _BV(1)),  1, &btn); // PumpAction → C
    press_if((b1 & _BV(2)),  3, &btn); // FrontLeft  → A
    press_if((b1 & _BV(3)),  2, &btn); // FrontRight → B
    press_if((b1 & _BV(4)), 14, &btn); // BackLeft   → Select
    press_if((b1 & _BV(5)), 15, &btn); // BackRight  → Start

    // Byte5 D-Pad (ACTIVE-HIGH): bit0 Up, bit1 Down, bit2 Left, bit3 Right
    press_if((bd & _BV(0)),  4, &btn); // Up
    press_if((bd & _BV(3)),  5, &btn); // Right
    press_if((bd & _BV(1)),  6, &btn); // Down
    press_if((bd & _BV(2)),  7, &btn); // Left

    g_report.buttons = btn;
}

int main(void)
{
    // Ensure 16MHz
    MCUSR = 0;
    clock_prescale_set(clock_div_1);

    UART_Init();
    PEDAL_Init();
    USB_Init();
    sei();

    for (;;)
    {
        USB_USBTask();

        // Debounce pedal
        uint8_t raw = PEDAL_IsPressedRaw();
        if (raw != pedalStable) {
            if (++pedalCnt >= PEDAL_DB_COUNT) {
                pedalStable  = raw;
                pedalCnt     = 0;
                pedalPressed = pedalStable;
            }
        } else {
            pedalCnt = 0;
        }

        // Consume one SerialPortSecondary frame if present
        UpdateFromSerialPortSecondary();

        // Pedal → Button A (bit 3, ACTIVE-LOW)
        if (pedalPressed) g_report.buttons &= ~(1u << 3);
        else              g_report.buttons |=  (1u << 3);

        // Send report if host polls
        GCN2_TrySend();
    }
}
