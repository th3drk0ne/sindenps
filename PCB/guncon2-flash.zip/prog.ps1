$hex = "guncon2.hex"
$avrdude = "$PSScriptRoot\avrdude.exe"
$config = "$PSScriptRoot\avrdude.conf"

$ports = @(Get-CimInstance Win32_SerialPort |
    Where-Object { $_.Name -notmatch 'Bluetooth|Active Management Technology' } |
    Sort-Object { [int]($_.DeviceID -replace '\D','') })

if ($ports.Count -eq 0) {
    Write-Host "No suitable COM ports found"
    exit 1
}

if ($ports.Count -eq 1) {
    $normalPort = $ports[0].DeviceID
    Write-Host "Using port: $normalPort"
}
else {
    Write-Host "Select COM port:`n"
    for ($i = 0; $i -lt $ports.Count; $i++) {
        Write-Host "$i`: $($ports[$i].DeviceID) - $($ports[$i].Name)"
    }

    $choice = Read-Host "Enter number"
    if ($choice -notmatch '^\d+$' -or [int]$choice -ge $ports.Count) { exit 1 }

    $normalPort = $ports[[int]$choice].DeviceID
}

$old = @([System.IO.Ports.SerialPort]::GetPortNames())

mode $normalPort BAUD=1200 PARITY=N data=8 stop=1 > $null 2>&1

$boot = $null
$seenGone = $false

for ($i = 0; $i -lt 40; $i++) {
    $now = @([System.IO.Ports.SerialPort]::GetPortNames())

    if ($now -notcontains $normalPort) {
        $seenGone = $true
    }

    $diff = @($now | Where-Object { $_ -notin $old })
    if ($diff.Count -gt 0) {
        $boot = $diff[-1]
        break
    }

    if ($seenGone -and $now -contains $normalPort) {
        $boot = $normalPort
        break
    }

    Start-Sleep -Milliseconds 250
}

if (-not $boot) {
    Write-Host "No bootloader port detected"
    exit 1
}

Write-Host "Using bootloader port: $boot"

& $avrdude "-C$config" -v -p atmega32u4 -c avr109 "-P$boot" -b 57600 -D "-Uflash:w:$hex`:i"

if ($LASTEXITCODE -ne 0) { exit 1 }

Write-Host "Upload successful"

Start-Sleep -Seconds 3

$expectedVID = "VID_0B9A"   # GunCon2
$expectedPID = "PID_016A"   

$device = Get-CimInstance Win32_PnPEntity |
    Where-Object { $_.PNPDeviceID -match "$expectedVID&$expectedPID" }

if ($device) {
    Write-Host "Device detected: GunCon2"
} else {
    Write-Host "Device not found"
}